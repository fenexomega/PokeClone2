keys = {}
keys["up"]      = 26
keys["down"]    = 22
keys["left"]    = 7
keys["right"]   = 4
keys["action"]  = 14
keys["cancel"]  = 15
