-- Mensagens do player
-- Definidos em Engine/Components/iComponent.h
PLAYER_NEAR = 0x10
PLAYER_INTERACTION = 0x11

DISSAPEAR = 0x20
MOVE_BACK = 0x21
CHANGE_MAP = 0x22
