#!/bin/bash

path=$(dirname $0)
cd $path
export LD_LIBRARY_PATH=.
./game
